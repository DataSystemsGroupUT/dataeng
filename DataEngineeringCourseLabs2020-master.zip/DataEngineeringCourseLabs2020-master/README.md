# DataEngineeringCourseLabs2020

* **ToDOS**:
  - Add the RElatioanal Algebra Notes [Stanford]
  - upload Slides of the Labs as PDFs
  - create questions bank out of the practice sessions.
